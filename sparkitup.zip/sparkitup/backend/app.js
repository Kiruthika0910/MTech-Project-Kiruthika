require('dotenv').config(); // Load environment variables
const express = require('express');
const bcrypt = require('bcryptjs');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');
const mysql = require('mysql2');
const cors = require('cors');
const path = require('path');

const app = express();

// Middleware setup
app.use(bodyParser.json());
app.use(cors());
app.use(express.static(path.join(__dirname, 'public'))); // Serve static files

// Create MySQL connection pool
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || 'Abirami@0207',
  database: process.env.DB_NAME || 'sparkitup_project',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

pool.on('error', (err) => {
  console.error('Unexpected database error:', err);
});

// JWT Secret Key
const SECRET_KEY = process.env.JWT_SECRET || 'your_secret_key';

// Register User
app.post('/register', (req, res) => {
  const { name, email, phone, location, role, service_type, experience, password } = req.body;

  bcrypt.hash(password, 10, (err, hashedPassword) => {
    if (err) return res.status(500).json({ success: false, message: 'Error hashing password' });

    const query = `
      INSERT INTO users (name, email, phone, location, role, service_type, experience, password) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `;
    pool.query(
      query,
      [name, email, phone, location, role, service_type || null, experience || 0, hashedPassword],
      (err, results) => {
        if (err) {
          console.error('Error registering user:', err);
          return res.status(500).json({ success: false, message: 'Error registering user', error: err.message });
        }

        res.json({ success: true, message: 'User registered successfully' });
      }
    );
  });
});

// Login User
app.post('/login', (req, res) => {
  const { email, password } = req.body;

  pool.query('SELECT * FROM users WHERE email = ?', [email], (err, results) => {
    if (err) {
      console.error('Error fetching user:', err);
      return res.status(500).json({ success: false, message: 'Error fetching user', error: err.message });
    }

    if (results.length === 0) {
      return res.status(401).json({ success: false, message: 'Invalid email or password' });
    }

    const user = results[0];
    bcrypt.compare(password, user.password, (err, isMatch) => {
      if (err || !isMatch) {
        return res.status(401).json({ success: false, message: 'Invalid email or password' });
      }

      const token = jwt.sign({ id: user.id, role: user.role }, SECRET_KEY, { expiresIn: '1h' });
      res.json({
        success: true,
        message: 'Login successful',
        token,
        user: { id: user.id, name: user.name, role: user.role }
      });
    });
  });
});

// Fetch Service Providers Based on Client's Location (Token validation removed)
app.post('/find-providers', (req, res) => {
  const { service_type, location } = req.body;

  const query = `
    SELECT id, name, location 
    FROM users 
    WHERE role = 'service_provider' AND service_type = ? AND location LIKE ?
  `;
  pool.query(query, [service_type, `%${location}%`], (err, results) => {
    if (err) {
      console.error('Error fetching providers:', err);
      return res.status(500).json({ success: false, message: 'Error fetching providers', error: err.message });
    }

    res.json({ success: true, providers: results });
  });
});

// Book a Service (Token validation removed)
app.post('/book', (req, res) => {
  const { service_type, location, provider_id, preferred_date, preferred_time } = req.body;

  const query = `
    INSERT INTO bookings (provider_id, service_type, location, preferred_date, preferred_time) 
    VALUES (?, ?, ?, ?, ?)
  `;
  pool.query(
    query,
    [provider_id, service_type, location, preferred_date, preferred_time],
    (err, results) => {
      if (err) {
        console.error('Error booking service:', err);
        return res.status(500).json({ success: false, message: 'Error booking service', error: err.message });
      }

      res.json({ success: true, message: 'Service booked successfully' });
    }
  );
});

// Fetch Booking History (Token validation removed)
app.get('/booking-history', (req, res) => {
  const { userId } = req.query; // Get userId directly from query parameters

  const query = `
    SELECT b.id, u.name AS provider_name, b.service_type, b.location, b.preferred_date, b.preferred_time 
    FROM bookings b 
    JOIN users u ON b.provider_id = u.id 
    WHERE b.client_id = ?
  `;
  pool.query(query, [userId], (err, results) => {
    if (err) {
      console.error('Error fetching booking history:', err);
      return res.status(500).json({ success: false, message: 'Error fetching booking history', error: err.message });
    }

    res.json({ success: true, bookings: results });
  });
});

// Serve static HTML files
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.get('/register', (req, res) => res.sendFile(path.join(__dirname, 'public', 'register.html')));
app.get('/login', (req, res) => res.sendFile(path.join(__dirname, 'public', 'login.html')));
app.get('/booking', (req, res) => res.sendFile(path.join(__dirname, 'public', 'booking-form.html')));
app.get('/booking-history', (req, res) => res.sendFile(path.join(__dirname, 'public', 'booking-history.html')));

// Start Server
const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
